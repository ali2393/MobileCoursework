package com.example.MobileCourseWork;

//Imports Libaries needed
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.example.MobileCourseWork.R;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import android.content.DialogInterface;
import android.view.Menu;


public class MainActivity extends Activity implements OnMapClickListener, OnMapLongClickListener, OnMarkerClickListener {
	
	//create map
	private GoogleMap theMap;
	
	final int RQS_GooglePlayServices = 1;
	
	//set up city positions
	final LatLng glasgowpos =  new LatLng(55.862212,-4.243684);
	final LatLng delhipos = new LatLng(28.707452,77.103209);
	final LatLng melbournepos = new LatLng(-37.811954,144.969664);
	final LatLng manchesterpos = new LatLng(53.479465,-2.248474);
	final LatLng kuala_Lumpurpos = new LatLng(3.139488,101.68631);
	final LatLng victoriapos = new LatLng(48.428175,-123.365505);
	final LatLng aucklandpos = new LatLng(-36.851054,174.764585);
	final LatLng edinburghpos = new LatLng(55.953813,-3.188202);
	final LatLng brisbanepos = new LatLng(-27.471153,153.023494);
	final LatLng edmontonpos = new LatLng(53.54398,-113.493683);
	final LatLng christchurchpos = new LatLng(50.736238,-1.778809);
	
	//set up markers
	private Marker DelhiMarker;
	private Marker MelbourneMarker;
	private Marker ManchesterMarker;
	private Marker Kuala_LumpurMarker;
	private Marker VictoriaMarker;
	private Marker AucklandMarker;
	private Marker EdinburghMarker;
	private Marker BrisbaneMarker;
	private Marker EdmontonMarker;
	private Marker ChristchurchMarker;
	
	private Marker AthleticsMarker;
	private Marker RugbyMarker;
	private Marker Athletics2Marker;
	private Marker SquashMarker;
	private Marker LawnBowlsMarker;
	private Marker BoxingMarker;
	private Marker Hockeymarker;
	private Marker AquaticsMarker;
	private Marker AquaticsMarker2;
	private Marker CyclingMarker;
	private Marker TriathlonMarker;
	
	private TextView tvLocInfo;
	 
	 boolean markerClicked;
	
	 @Override
    protected void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //find view
        tvLocInfo = (TextView)findViewById(R.id.locinfo);
        
        //sets up the map
        if(theMap==null){
            //map not instantiated yet
        	theMap = ((MapFragment)getFragmentManager().findFragmentById(R.id.map)).getMap();
        }
        if(theMap != null){
            //ok - proceed
        	theMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(55.860552,-4.257992),13.0f));
        	theMap.setMyLocationEnabled(true);
        	  
        	//set the initial map type
        	theMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        	  
        	//set up the map listeners
        	theMap.setOnMapClickListener(this);
        	theMap.setOnMapLongClickListener(this);
        	theMap.setOnMarkerClickListener(this);

        	markerClicked = false;
        	        	
        	//creates the markers by creating marker options that hold the title position
        	//and icon of the marker then placing the marker on the map and setting it to the appropriate marker
        	
        	//Markers for city's
        	MarkerOptions Delhi = new MarkerOptions().position(delhipos).title("Delhi");
        	Delhi.icon(BitmapDescriptorFactory.fromResource(R.drawable.regroup));
        	DelhiMarker = theMap.addMarker(Delhi);
        	
        	MarkerOptions Melbourne = new MarkerOptions().position(melbournepos).title("Melbourne");
        	Melbourne.icon(BitmapDescriptorFactory.fromResource(R.drawable.regroup));
        	MelbourneMarker = theMap.addMarker(Melbourne);
        	
        	MarkerOptions Manchester = new MarkerOptions().position(manchesterpos).title("Manchester");
        	Manchester.icon(BitmapDescriptorFactory.fromResource(R.drawable.regroup));
        	ManchesterMarker = theMap.addMarker(Manchester);
        	
        	MarkerOptions Kuala_Lumpur = new MarkerOptions().position(kuala_Lumpurpos).title("Kuala Lumpur");
        	Kuala_Lumpur.icon(BitmapDescriptorFactory.fromResource(R.drawable.regroup));
        	Kuala_LumpurMarker = theMap.addMarker(Kuala_Lumpur);
        	
        	MarkerOptions Victoria = new MarkerOptions().position(victoriapos).title("Victoria");
        	Victoria.icon(BitmapDescriptorFactory.fromResource(R.drawable.regroup));
        	VictoriaMarker = theMap.addMarker(Victoria);
        	
        	MarkerOptions Auckland = new MarkerOptions().position(aucklandpos).title("Auckland");
        	Auckland.icon(BitmapDescriptorFactory.fromResource(R.drawable.regroup));
        	AucklandMarker = theMap.addMarker(Auckland);
        	
        	MarkerOptions Edinburgh = new MarkerOptions().position(edinburghpos).title("Edinburgh");
        	Edinburgh.icon(BitmapDescriptorFactory.fromResource(R.drawable.regroup));
        	EdinburghMarker = theMap.addMarker(Edinburgh);
        	
        	MarkerOptions Brisbane = new MarkerOptions().position(brisbanepos).title("Brisbane");
        	Brisbane.icon(BitmapDescriptorFactory.fromResource(R.drawable.regroup));
        	BrisbaneMarker = theMap.addMarker(Brisbane);
        	
        	MarkerOptions Edmonton = new MarkerOptions().position(edmontonpos).title("Edmonton");
        	Edmonton.icon(BitmapDescriptorFactory.fromResource(R.drawable.regroup));
        	EdmontonMarker = theMap.addMarker(Edmonton);
        	
        	MarkerOptions Christchurch = new MarkerOptions().position(christchurchpos).title("Christchurch");
        	Christchurch.icon(BitmapDescriptorFactory.fromResource(R.drawable.regroup));
        	ChristchurchMarker = theMap.addMarker(Christchurch);

        	
        	//markers for sports
        	MarkerOptions Athletics = new MarkerOptions().position(new LatLng(55.825461,-4.251893)).title("Hampden Park");
        	Athletics.icon(BitmapDescriptorFactory.fromResource(R.drawable.stadium));
        	AthleticsMarker = theMap.addMarker(Athletics);
        	
        	MarkerOptions Rugby = new MarkerOptions().position(new LatLng(55.853288,-4.309282)).title("Ibrox Stadium");
        	Rugby.icon(BitmapDescriptorFactory.fromResource(R.drawable.rugbyfield));
        	RugbyMarker = theMap.addMarker(Rugby);
        	
        	MarkerOptions Athletics2 = new MarkerOptions().position(new LatLng(55.84688,-4.207519)).title("Commonwealth Arena & Velodrome");
        	Athletics2.icon(BitmapDescriptorFactory.fromResource(R.drawable.stadium));
        	Athletics2Marker = theMap.addMarker(Athletics2);
        	
        	MarkerOptions Squash = new MarkerOptions().position(new LatLng(55.879524,-4.339968)).title("Scotstoun Sports Campus");
        	Squash.icon(BitmapDescriptorFactory.fromResource(R.drawable.squash));
        	SquashMarker = theMap.addMarker(Squash);
        	
        	MarkerOptions LawnBowls = new MarkerOptions().position(new LatLng(55.867401,-4.288319)).title("Kelvingrove Lawn Bowls Centre");
        	LawnBowls.icon(BitmapDescriptorFactory.fromResource(R.drawable.bollie));
        	LawnBowlsMarker = theMap.addMarker(LawnBowls);
        	
        	MarkerOptions Boxing = new MarkerOptions().position(new LatLng(55.860622,-4.287525)).title("SECC Precinct");
        	Boxing.icon(BitmapDescriptorFactory.fromResource(R.drawable.boxing));
        	BoxingMarker = theMap.addMarker(Boxing);
        	
        	MarkerOptions Hockey = new MarkerOptions().position(new LatLng(55.845301,-4.236702)).title("Glasgow National Hockey Centre");
        	Hockey.icon(BitmapDescriptorFactory.fromResource(R.drawable.icehockey));
        	Hockeymarker = theMap.addMarker(Hockey);
        	
        	MarkerOptions Aquatics = new MarkerOptions().position(new LatLng(55.845109,-4.176117)).title("Tollcross Swimming Centre");
        	Aquatics.icon(BitmapDescriptorFactory.fromResource(R.drawable.swimming));
        	AquaticsMarker = theMap.addMarker(Aquatics);
        	
        	MarkerOptions Aquatics2 = new MarkerOptions().position(new LatLng(55.939034,-3.172842)).title("Tollcross Swimming Centre");
        	Aquatics2.icon(BitmapDescriptorFactory.fromResource(R.drawable.swimming));
        	AquaticsMarker2 = theMap.addMarker(Aquatics2);
        	
        	MarkerOptions Cycling = new MarkerOptions().position(new LatLng(55.794309,-4.219014)).title("Cathkin Braes Mountain Bike Park");
        	Cycling.icon(BitmapDescriptorFactory.fromResource(R.drawable.cycling));
        	CyclingMarker = theMap.addMarker(Cycling);
        	
        	MarkerOptions Triathlon = new MarkerOptions().position(new LatLng(55.785358,-4.014486)).title("Strathclyde Country park");
        	Triathlon.icon(BitmapDescriptorFactory.fromResource(R.drawable.startrace));
        	TriathlonMarker = theMap.addMarker(Triathlon);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
     // Inflate the menu; this adds items to the action bar if it is present.
     getMenuInflater().inflate(R.menu.main, menu);
     return true;
    }

    
    @Override
   public boolean onOptionsItemSelected(MenuItem item) {
    	
    	//creates an array of map types
    		final CharSequence[] types={"Normal","Hybrid","Satellite","Terrain"};
    	
    		//makes a dialog box
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setTitle("Choose a Map mode");
			//creates a list using the types array, sets the default to 1 and sets up onClick listeners for the options
			info.setSingleChoiceItems(types, 1, new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int types) {
					//case statement to switch the map type depending on what is selected
					switch(types)
					{
					case 0:
						theMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
						break;
						
					case 1:
						theMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
						break;
						
					case 2:
						theMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
						break;
						
					case 3:
						theMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
						break;
					}
					
				}
			});
					{
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();

					}
     return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
     // TODO Auto-generated method stub
     super.onResume();

     int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getApplicationContext());
     
     if (resultCode == ConnectionResult.SUCCESS){
      Toast.makeText(getApplicationContext(), 
        "isGooglePlayServicesAvailable SUCCESS", 
        Toast.LENGTH_LONG).show();
     }else{
      GooglePlayServicesUtil.getErrorDialog(resultCode, this, RQS_GooglePlayServices);
     }
     
    }

    @Override
    public void onMapClick(LatLng point) {
     tvLocInfo.setText(point.toString());
     theMap.animateCamera(CameraUpdateFactory.newLatLng(point));
     
     markerClicked = false;
    }

    @Override
    public void onMapLongClick(LatLng point){   	
    	//sets up a array of city's
	final CharSequence[] City={"Glasgow","Delhi","Melbourne","Manchester","Kuala Lumpur","Victoria","Auckland","Edinburgh","Brisbane","Edmonton","Christchurch"};

	//as with the map types creates a dialog box with a list of selectable city's
	AlertDialog.Builder info = new AlertDialog.Builder(this);
	info.setTitle("Choose a City");
	info.setSingleChoiceItems(City, 0, new DialogInterface.OnClickListener() {
		
		@Override
		public void onClick(DialogInterface dialog, int types) {
			//moves the camera to the city that is selected
			switch(types)
			{
			case 0:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(glasgowpos));
				break;
				
			case 1:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(delhipos));
				break;
				
			case 2:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(melbournepos));
				break;
				
			case 3:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(manchesterpos));
				break;
				
			case 4:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(kuala_Lumpurpos));
				break;
				
			case 5:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(victoriapos));
				break;
				
			case 6:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(aucklandpos));
				break;
				
				
			case 7:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(edinburghpos));
				break;
				
			case 8:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(brisbanepos));
				break;
				
			case 9:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(edmontonpos));
				break;
				
			case 10:
				theMap.animateCamera(CameraUpdateFactory.newLatLng(christchurchpos));
				break;
			}
			
		}
	});
			{
	info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
	public void onClick(DialogInterface dialog, int whichButton) {
    dialog.cancel();
}
});
AlertDialog infoDialog = info.create();
infoDialog.show();

			}
}

    

    
    @Override
    public boolean onMarkerClick(Marker marker) {
     //sets up strings to be used in the dialog boxes 
     String Delhi ="Country: India"+ 
 			 "\nHost city: Delhi" + 
 			 "\nYear of Games: 2010"+
 			 "\nNo of Medals won by Scotland: 7";
     
     String Melbourne ="Country: Australia"+ 
 			 "\nHost city Melbourne:" + 
 			 "\nYear of Games: 2006"+
 			 "\nNo of Medals won by Scotland: 11";
     
     String Manchester ="Country: England"+ 
 			 "\nHost city: Manchester" + 
 			 "\nYear of Games: 2002"+
 			 "\nNo of Medals won by Scotland: 15";
     
     String Kuala_Lumpur ="Country: Malaysia"+ 
 			 "\nHost city: Kuala Lumpur" + 
 			 "\nYear of Games: 1998"+
 			 "\nNo of Medals won by Scotland: 12";
     
     String Victoria ="Country: Canada"+ 
 			 "\nHost city: Victoria" + 
 			 "\nYear of Games: 1994"+
 			 "\nNo of Medals won by Scotland: 20";
     
     String Auckland ="Country: New Zealand"+ 
 			 "\nHost city: Auckland" + 
 			 "\nYear of Games: 1990"+
 			 "\nNo of Medals won by Scotland: 22";
     
     String Edinburgh ="Country: Scotland"+ 
 			 "\nHost city: Edinburgh" + 
 			 "\nYear of Games: 1986"+
 			 "\nNo of Medals won by Scotland: 33";
     
     String Brisbane ="Country: Australia"+ 
 			 "\nHost city: Brisbane" + 
 			 "\nYear of Games: 1982"+
 			 "\nNo of Medals won by Scotland: 26";
     
     String Edmonton ="Country: Canada"+ 
 			 "\nHost city: Edmonton" + 
 			 "\nYear of Games: 1978"+
 			 "\nNo of Medals won by Scotland:14";
     
     String Christchurch ="Country: New Zealand"+ 
 			 "\nHost city: Christchurch" + 
 			 "\nYear of Games: 1974"+
 			 "\nNo of Medals won by Scotland: 19";
     
     String Athletics ="Name: Hampden Park"+ 
 			 "\nSport: Athletics" + 
 			 "\nAddress: Letherby Drive, Glasgow G42 9BA";
     
 	 String Rugby="Name: Ibrox Stadium"+ 
 			 "\nSport: Rugby" + 
 			 "\nAddress: 150 Edmiston Drive, Glasgow, Lanarkshire G51 2XD";
 	 
 	 String Athletics2="Name: Chris Hoy Velodrome"+ 
 			 "\nSport: Athletics" + 
 			 "\nAddress: 1000 London Road, Glasgow G40 3HY";
 	 
 	 String Squash ="Name: Scotstound Sports Campus" +
 	 		"\nSport: Squash " +
 	 		"\nAddress: 72 Danes Drive,Glasgow G14 9HD";
 	 
 	 String LawnBowls="Name: Kelvingrove Lawn Bowls Centre"+ 
 			 "\nSport: Lawn Bowls" + 
 			 "\nAddress: Kelvin Way, Glasgow, Glasgow City G3 7TA";
 	 
 	 String Boxing="Name: Scottish Exhibition and Conference Centre"+ 
 			 "\nSport: Boxing" + 
 			 "\nAddress: Exhibition Way, Glasgow G3 8YW";
 	 
 	 String Hockey="Name: National Hockey Centre"+ 
 			 "\nSport: Hockey" + 
 			 "\nAddress: Glasgow National Hockey Centre, 8 King's Drive, Glasgow, G40 1HB";
 	 
 	 String Aquatics="Name: Tollcross International Swimming Centre"+ 
 			 "\nSport: Aquatics" + 
 			 "\nAddress: 367 Wellshot Rd, Glasgow G32 7QP";
 	 
 	 String Aquatics2="Name: Royal Commonwealth Pool"+ 
 			 "\nSport: Aquatics" + 
 			 "\nAddress: 21 Dalkeith Rd, Edinburgh, Midlothian EH16 5BB";
 	 
 	 String Cycling="Name: Cathkin Braes Mountain Bike Track"+ 
 			 "\nSport: Cycling" + 
 			 "\nAddress: 231 George Street Glasgow G1 1RX";
 	 
 	 String Triathlon="Name: Strathclyde Country Park"+ 
 			 "\nSport: Triathlon" + 
 			 "\nAddress: 366 Hamilton Rd, Motherwell ML1 3ED";
     
 	 //creates a dialog box when a marker is clicked and puts the appropriate string as a message
 	 
 	 //dialog boxes for city's
    	if(marker.equals(DelhiMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Delhi);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(MelbourneMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Melbourne);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(ManchesterMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Manchester);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(Kuala_LumpurMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Kuala_Lumpur);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(VictoriaMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Victoria);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(AucklandMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Auckland);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(EdinburghMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Edinburgh);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(BrisbaneMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Brisbane);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(EdmontonMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Edmonton);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(ChristchurchMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Christchurch);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	
    	
    	//Dialog boxes for sports
    	if(marker.equals(AthleticsMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Athletics);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(RugbyMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Rugby);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(Athletics2Marker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Athletics2);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(SquashMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Squash);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(LawnBowlsMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(LawnBowls);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(BoxingMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Boxing);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(Hockeymarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Hockey);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(AquaticsMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Aquatics);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(AquaticsMarker2))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Aquatics2);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(CyclingMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Cycling);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	if(marker.equals(TriathlonMarker))
		{
			AlertDialog.Builder info = new AlertDialog.Builder(this);
			info.setMessage(Triathlon);
			info.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
            dialog.cancel();
        }
    });
    AlertDialog infoDialog = info.create();
    infoDialog.show();
		}
    	
    	
    	
     return true;
    }

   }
