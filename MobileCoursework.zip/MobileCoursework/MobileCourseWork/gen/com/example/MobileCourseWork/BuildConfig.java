/** Automatically generated file. DO NOT MODIFY */
package com.example.MobileCourseWork;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}